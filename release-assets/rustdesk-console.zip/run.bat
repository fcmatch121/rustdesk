@echo off
rem RustDesk 콘솔 (Java) 실행 — JDK 11 이상 필요
java -jar "%~dp0rustdesk-console.jar"
